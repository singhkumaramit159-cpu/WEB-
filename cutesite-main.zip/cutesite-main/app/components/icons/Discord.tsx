import React from 'react';

const Discord = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 32 32"
    {...props}
  >
    <path
      fill="currentColor"
      d="M30.47 9.14h-1.52V6.09h-1.53V4.57H25.9V3.05h-3.05V1.52h-3.04V0h-7.62v1.52H9.14v1.53H6.09v1.52H4.57v1.52H3.04v3.05H1.52v3.05H0v7.62h1.52v3.05h1.52v3.04h1.53v1.53h1.52v1.52h3.05v1.53h3.05V32h7.62v-1.52h3.04v-1.53h3.05v-1.52h1.52V25.9h1.53v-3.04h1.52v-3.05H32v-7.62h-1.53Zm-1.52 12.19h-1.53v1.53H25.9v1.52h-1.52v1.52h-6.1v-1.52h4.57v-3.05H9.14v3.05h4.57v1.52h-6.1v-1.52H6.09v-1.52H4.57v-1.53H3.04v-7.62h1.53v-3.04h1.52V9.14h1.52V7.62h6.1v1.52h4.57V7.62h6.1v1.52h1.52v1.53h1.52v3.04h1.53Z"
    />
    <path
      fill="currentColor"
      d="M18.28 13.71h3.05v3.05h-3.05Zm-7.62 0h3.05v3.05h-3.05Z"
    />
  </svg>
);

export default Discord;